/* 

=========================================================================
buy panel pm aja wok
https://wa.me/6287870946702
=========================================================================

*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")


//===============[ SETTINGS BOT ]===============//
global.owner = '6287870946702'
global.versi = 1.0.0 by Fathy
global.namaOwner = "Fathy"
global.packname = 'Fathy bot'
global.botname = 'まひるちゃん'
global.botname2 = 'まひるちゃん - Botz'

global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah
//=================================== === == =  =


//===============[ SETTINGS LINK ]===============//
global.linkOwner = "https://wa.me/6287870946702"
global.linkGrup = "https://chat.whatsapp.com/KgYoUuTsuLm6MZno3gTVTp"
//=================================== === == =  =


//===============[ SETTINGS DELAY ]===============//
// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 7000
global.delayPushkontak = 6000
//=================================== === == =  =


//===============[ SETTINGS CHANNEL ]===============//
global.linkSaluran = "https://whatsapp.com/channel/0029VasouxcCnA7m0d2k9v0P"
global.idSaluran = "120363367035030990@newsletter"
global.namaSaluran = "まひるちゃん"
//=================================== === == =  =


//===============[ API ORKUT ]===============//
//Tapi kyknya di bot ini gada fiturnya
global.merchantIdOrderKuota = "OK2102800"
global.apiOrderKuota = "919355217361254162102800OKCT4BE3587F1EA4BDCE0424FD94F874583C"
global.qrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214757501012374600303UMI51440014ID.CO.QRIS.WWW0215ID20243553591990303UMI5204541153033605802ID5921WILDAN ALFA OK21028006008TABALONG61057157162070703A01630411C2"
//=================================== === == =  =


//===============[ API DIGITAL OCEAN ]===============//
global.apiDigitalOcean = "-"
// Settings Api Digital Ocean
global.apiSimpelBot = "new2025"
//=================================== === == =  =


//===============[ SETTINGS PAYMENT ]===============//
global.dana = "087709137809"
global.ovo = "Tidak Tersedia"
global.gopay = "Tidak Tersedia"
//=================================== === == =  =


//===============[ SETTINGS IMAGE URL ]===============//
global.image = {
thumb: "https://files.catbox.moe/6shvud.jpg",

menu: "https://files.catbox.moe/6shvud.jpg", 
akses: "https://files.catbox.moe/6shvud.jpg",
reply: "https://files.catbox.moe/6shvud.jpg", 
logo: "https://files.catbox.moe/6shvud.jpg", 

qris: "https://files.catbox.moe/x9hnxi.jpg",
dana: "https://files.catbox.moe/x9hnxi.jpg", 
ovo: "https://files.catbox.moe/x9hnxi.jpg", 
gopay: "https://files.catbox.moe/x9hnxi.jpg", 

welcome: "https://files.catbox.moe/6shvud.jpg",
bye: "https://files.catbox.moe/6shvud.jpg",
}
//=================================== === == =  =


//===============[ API PTERODACTYL ]===============//
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://-"
global.apikey = "-" //ptla
global.capikey = "-" //ptlc
//=================================== === == =  =


//===============[ API PTERODACTYL 2 ]===============//
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://-"
global.apikeyV2 = "-" //ptla
global.capikeyV2 = "-" //ptlc
//=================================== === == =  =


//===============[ SETTINGS API SUBDOMAIN ]===============//
global.subdomain = {
"privatehost.us.kg": {
"zone": "790918217c4add75b7684458518c5836", 
"apitoken": "qYv4NvEN6ZcUIv4dEXihjkmQMwbP_-3Qy_zFlAHv"
}, 
"botwhatsapp.us.kg": {
"zone": "fb1ac418c5564373a56c91d962b30dca", 
"apitoken": "rfQih0XNXiq7AyEuDoLjoFfHX2mhYf_9kddAdKIo"
}, 
"skyzopedia.us.kg": {
"zone": "9e4e70b438a65c1d3e6d0e48b82d79de", 
"apitoken": "odilM9DpvLVPodbPyZwW7UcDKg1aIWsivJc0Vt_o"
}, 
"marketplace.us.kg": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "HXVf4soYFM3iiOewHZ6tk6LEnG9f7m7CVhU0EoVz"
}, 
"xyz-store.biz.id": {
"zone": "8ae812c35a94b7bd2da993a777b8b16d", 
"apitoken": "oqZafkd3mSt1bABD9MMTidpCtD9VZdiPTjElVKJB"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
}
}
//=================================== === == =  =


//===============[ MASSAGE COMMAND ]===============//
global.mess = {
	owner: "*Akses Ditolak*\n_Fitur ini hanya untuk owner bot!_",
	premium: "*Akses Ditolak*\n_Fitur ini hanya untuk user premium!_",
	admin: "*Akses Ditolak*\n_Fitur ini hanya untuk admin grup!_",
	botAdmin: "*Akses Ditolak*\n_Fitur ini hanya untuk ketika bot menjadi admin!_",
	group: "*Akses Ditolak*\n_Fitur ini hanya untuk dalam grup!_",
	private: "*Akses Ditolak*\n_Fitur ini hanya untuk dalam private chat!_",
	prem: "*Akses Ditolak*\n_Fitur ini hanya untuk user premium!_",
	wait: 'Loading...',
	error: 'Error!',
	done: '\`Done\`'
}
//=================================== === == =  =


//===============[ TEKS MENU ]===============//
global.othermenu = ` *\`⊰⊹ 𝔒𝔱𝔥𝔢𝔯 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  nextmenu
  ェ  cekidch
  ェ  cekidgc
  ェ  qc
  ェ  brat
  ェ  readviewonce
  ェ  stickerwm
  ェ  sticker
  ェ  sewa
  ェ  donasi`
global.searchmenu = ` *\`⊰⊹ 𝔖𝔢𝔞𝔯𝔠𝔥 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  yts
  ェ  apkmod
  ェ  pinterest`
global.toolsmenu = ` *\`⊰⊹ 𝔗𝔬𝔬𝔩𝔰 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  ai
  ェ  gpt
  ェ  tourl
  ェ  tourl2
  ェ  ssweb
  ェ  translate
  ェ  tohd
  ェ  shortlink
  ェ  shortlink2
  ェ  enc`
global.downloadmenu = ` *\`⊰⊹ 𝔇𝔬𝔴𝔫𝔩𝔬𝔞𝔡 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  tiktok
  ェ  tiktokmp3
  ェ  instagram
  ェ  ytmp3
  ェ  ytmp4
  ェ  play
  ェ  gitclone
  ェ  mediafire`
global.groupmenu = ` *\`⊰⊹ 𝔊𝔯𝔬𝔲𝔭 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  add
  ェ  kick
  ェ  close
  ェ  open
  ェ  hidetag
  ェ  kudetagc
  ェ  leave
  ェ  tagall
  ェ  promote
  ェ  demote
  ェ  resetlinkgc
  ェ  on
  ェ  off
  ェ  linkgc`
global.funmenu = ` *\`⊰⊹ 𝔉𝔲𝔫 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  tiktokvids
  ェ  cekkhodam`
global.panelmenu = ` *\`⊰⊹ 𝔓𝔞𝔫𝔢𝔩 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  addseller
  ェ  delseller
  ェ  listseller
  ェ  1gb
  ェ  2gb
  ェ  3gb
  ェ  4gb
  ェ  5gb
  ェ  6gb
  ェ  7gb
  ェ  8gb
  ェ  9gb
  ェ  10gb
  ェ  11gb
  ェ  12gb
  ェ  13gb
  ェ  14gb
  ェ  15gb
  ェ  16gb
  ェ  17gb
  ェ  18gb
  ェ  19gb
  ェ  20gb
  ェ  unlimited
  ェ  cadmin
  ェ  delpanel
  ェ  deladmin
  ェ  listpanel
  ェ  listadmin`
global.ownermenu = ` *\`⊰⊹ 𝔒𝔴𝔫𝔢𝔯 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  autoread
  ェ  autopromosi
  ェ  autoreadsw
  ェ  autotyping
  ェ  addplugins
  ェ  listplugins
  ェ  delplugins
  ェ  getplugins
  ェ  saveplugins
  ェ  addowner
  ェ  listowner
  ェ  delowner
  ェ  self/public
  ェ  setimgmenu
  ェ  setimgfake
  ェ  setppbot
  ェ  clearsession
  ェ  clearchat
  ェ  resetdb
  ェ  restartbot
  ェ  getsc
  ェ  getcase
  ェ  listgc
  ェ  joingc
  ェ  joinch
  ェ  upchannel
  ェ  upchannel2
  ェ    ----------
  ェ  addrespon
  ェ  delrespon
  ェ  listrespon
  ェ  done
  ェ  proses
  ェ  jpm
  ェ  jpm2
  ェ  jpmhidetag
  ェ  jpmhidetag2
  ェ  jpmtesti
  ェ  sendtesti
  ェ  pushkontak
  ェ  pushkontak2
  ェ  payment
  ェ  produk
  ェ  subdomain`
global.allmenu = `${othermenu}\n\n${groupmenu}\n\n${downloadmenu}\n\n${toolsmenu}\n\n${searchmenu}\n\n${funmenu}\n\n${panelmenu}\n\n${ownermenu}`
//=================================== === == =  =


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})