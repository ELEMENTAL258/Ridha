const fs = require("fs")
const os = require('os');

let handler = async (m, { Sky, isCreator, isPremium, qtext, runtime, toIDR, Reply }) => {
let teksnya = `
\`USER - INFORMATION\`
  • Number : ${m.sender.split("@")[0]}
  • Status : *${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}*

*\`FITUR KHUSUS:\`*
\`• Orang spesial\`
\`• Owner\`
\`• Creator\`

 *\`⊰⊹ 𝔖𝔱𝔬𝔯𝔢 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  addrespon
  ェ  delrespon
  ェ  listrespon
  ェ  done
  ェ  proses
  ェ  jpm
  ェ  jpm2
  ェ  jpmhidetag
  ェ  jpmhidetag2
  ェ  jpmtesti
  ェ  sendtesti
  ェ  pushkontak
  ェ  pushkontak2
  ェ  payment
  ェ  produk
  ェ  subdomain
  
 *\`⊰⊹ 𝔇𝔦𝔤𝔦𝔱𝔞𝔩 𝔒𝔠𝔢𝔞𝔫 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  r1c1
  ェ  r2c1
  ェ  r4c2
  ェ  r8c4
  ェ  r16c4
  ェ  sisadroplet
  ェ  deldroplet
  ェ  listdroplet
  ェ  rebuild
  ェ  restartvps
  
 *\`⊰⊹ 𝔓𝔞𝔫𝔢𝔩 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  addseller
  ェ  delseller
  ェ  listseller
  ェ  1gb
  ェ  2gb
  ェ  3gb
  ェ  4gb
  ェ  5gb
  ェ  6gb
  ェ  7gb
  ェ  8gb
  ェ  9gb
  ェ  10gb
  ェ  11gb
  ェ  12gb
  ェ  13gb
  ェ  14gb
  ェ  15gb
  ェ  16gb
  ェ  17gb
  ェ  18gb
  ェ  19gb
  ェ  20gb
  ェ  unlimited
  ェ  cadmin
  ェ  delpanel
  ェ  deladmin
  ェ  listpanel
  ェ  listadmin
    
 *\`⊰⊹ 𝔓𝔞𝔫𝔢𝔩 𝔐𝔢𝔫𝔲 𝔒𝔴𝔫𝔢𝔯 ⊹⊱\`*
  ェ  1gb-v2
  ェ  2gb-v2
  ェ  3gb-v2
  ェ  4gb-v2
  ェ  5gb-v2
  ェ  6gb-v2
  ェ  7gb-v2
  ェ  8gb-v2
  ェ  9gb-v2
  ェ  10gb-v2
  ェ  unlimited-v2
  ェ  cadmin-v2
  ェ  delpanel-v2
  ェ  deladmin-v2
  ェ  listpanel-v2
  ェ  listadmin-v2
  
 *\`⊰⊹ ℑ𝔫𝔰𝔱𝔞𝔩𝔩𝔢𝔯 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  hackbackpanel
  ェ  installpanel
  ェ  installtemastellar
  ェ  installtemabilling
  ェ  installtemaenigma
  ェ  uninstallpanel
  ェ  uninstalltema
  
 *\`⊰⊹ 𝔒𝔴𝔫𝔢𝔯 𝔐𝔢𝔫𝔲 ⊹⊱\`*
  ェ  autoread
  ェ  autopromosi
  ェ  autoreadsw
  ェ  autotyping
  ェ  addplugins
  ェ  listplugins
  ェ  delplugins
  ェ  getplugins
  ェ  saveplugins
  ェ  addowner
  ェ  listowner
  ェ  delowner
  ェ  self/public
  ェ  setimgmenu
  ェ  setimgfake
  ェ  setppbot
  ェ  clearsession
  ェ  clearchat
  ェ  resetdb
  ェ  restartbot
  ェ  getsc
  ェ  getcase
  ェ  listgc
  ェ  joingc
  ェ  joinch
  ェ  upchannel
  ェ  upchannel2
`
await Sky.sendMessage(m.chat, {react: {text: '⏱', key: m.key}})
await sleep(400)
await Reply(`${teksnya}`)
await Sky.sendMessage(m.chat, {react: {text: '', key: m.key}})
}

handler.command = ["nextmenu"]

module.exports = handler