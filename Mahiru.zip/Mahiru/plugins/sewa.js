const fs = require("fs")
const os = require('os');

let handler = async (m, { Sky, isCreator, isPremium, qtext, runtime, toIDR }) => {
let teksnya = `
╭━━━━「 SEWA BOT 」
┊⫹⫺ Hemat _7day_ : 5K/grup
┊⫹⫺ Normal _30day_ : 8K/grup
┊⫹⫺ Permanen : 10K/grup
╰═┅═━––––––๑

*\`Feature:\`*
 - On / Off
 - Welcome
 - Antilink | Kick mmember
 - Antilink2 | Hapus pesan link
 - Brat | Pembuat Stiker teks
 - Sticker | Foto to stiker
 - Qc | Stiker pesan
 - Play | Play musik
 - Toimg | Stiker to foto
 - Downloader | tt/ig/yt/dll
 - Hidetag
 - Translate
 - Chat Ai
 - Download Apk Mod
 - DLL

\`\`\`Ga Rugi Pokok E Sewa Bot Di Sini
Feature Melimpah Bosqu\`\`\`

*Minat Ketik _.owner_*
Pembayaran Bisa Lewat QRIS
`
await Sky.sendMessage(m.chat, {text: teksnya, mentions: [m.sender, global.owner+"@s.whatsapp.net"]}, {quoted: qtext})
}

handler.command = ["sewa"]

module.exports = handler